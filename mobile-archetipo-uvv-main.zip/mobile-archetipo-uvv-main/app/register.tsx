import React, { useState } from 'react';
import { Button, StyleSheet, TextInput, View, Text } from 'react-native';
import { useAuth } from '@/contexts/AuthContext';

export default function RegisterScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleRegister = async () => {
    try {
      setError(null);
      setSuccess(null);

      if (password !== confirmPassword) {
        setError('Passwords do not match.');
        return;
      }

      // Aqui você faria a chamada para a API de registro.
      // Exemplo: const response = await api.register(email, password);
      const response = { status: 201 }; // Simulação para teste
      if (response.status === 201) {
        setSuccess('Account created successfully! You can now log in.');
        setEmail('');
        setPassword('');
        setConfirmPassword('');
      } else {
        throw new Error('Failed to register. Please try again.');
      }
    } catch (err) {
      setError('Failed to register. Please try again.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Register</Text>
      {error && <Text style={styles.error}>{error}</Text>}
      {success && <Text style={styles.success}>{success}</Text>}
      <TextInput
        style={styles.input}
        placeholder="Email"
        keyboardType="email-address"
        autoCapitalize="none"
        onChangeText={setEmail}
        value={email}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        secureTextEntry
        onChangeText={setPassword}
        value={password}
      />
      <TextInput
        style={styles.input}
        placeholder="Confirm Password"
        secureTextEntry
        onChangeText={setConfirmPassword}
        value={confirmPassword}
      />
      <Button title="Register" onPress={handleRegister} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 16 },
  title: { fontSize: 24, marginBottom: 16, textAlign: 'center' },
  input: { borderWidth: 1, padding: 12, marginBottom: 8, borderRadius: 4 },
  error: { color: 'red', marginBottom: 16 },
  success: { color: 'green', marginBottom: 16 },
});
