import React, { createContext, useContext, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

// Tipagem para o contexto
interface AuthContextProps {
  user: User | null;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  isAuthenticated: boolean;
  loading: boolean;
}

interface User {
  id: string;
  email: string;
  token: string;
}

// Contexto criado
const AuthContext = createContext<AuthContextProps | undefined>(undefined);

// Provider para encapsular o aplicativo
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);

  // Função de login
  const signIn = async (email: string, password: string) => {
    try {
      setLoading(true);

      // Chamada para a API
      const response = await axios.post('http://localhost:3000/auth/signin', {
        email,
        password,
      });

      if (response.data.status === 200) {
        const userData: User = {
          id: response.data.user.id,
          email,
          token: response.data.user.token,
        };

        setUser(userData);

        // Salvar dados localmente
        await AsyncStorage.setItem('@user', JSON.stringify(userData));
      } else {
        throw new Error(response.data.message);
      }
    } catch (error) {
      console.error('Erro ao fazer login:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Função de logout
  const signOut = async () => {
    try {
      setLoading(true);

      // Remover dados do AsyncStorage
      await AsyncStorage.removeItem('@user');
      setUser(null);
    } catch (error) {
      console.error('Erro ao fazer logout:', error);
    } finally {
      setLoading(false);
    }
  };

  // Verificar autenticação inicial
  React.useEffect(() => {
    const loadUserData = async () => {
      try {
        setLoading(true);
        const userData = await AsyncStorage.getItem('@user');
        if (userData) {
          setUser(JSON.parse(userData));
        }
      } catch (error) {
        console.error('Erro ao carregar dados do usuário:', error);
      } finally {
        setLoading(false);
      }
    };

    loadUserData();
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        signIn,
        signOut,
        isAuthenticated: !!user,
        loading,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

// Hook para usar o contexto
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider');
  }
  return context;
};
